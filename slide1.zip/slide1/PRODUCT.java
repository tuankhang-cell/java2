package slide1;

public class PRODUCT {
	private String id;
	private String name;
	private double basePrice;
	
	public PRODUCT() {}
	public PRODUCT(String id, String name, double basePrice) {
		this.id=id;
		this.name=name;
		this.basePrice=basePrice;
	}
	public String getID() {
		return this.id;
	}
	public boolean setID(String id) {
		if(id!= null) {
			this.id=id;
			return true;
		}else {
			return false;
		}
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getBasePrice() {
		return basePrice;
	}
	public boolean setBasePrice(double basePrince) {
		if(basePrince >=0) {
		this.basePrice = basePrince;
		return true;
	}else {
		return false;
	}
	}
		public double finalPrice() {
			return this.basePrice;
			
		}
		public String xuat() {
			return "Mã:"+id +"\nTên:" + name +"\nGia:"+ basePrice;}
			@Override
			public String toString() {
				return String.format("%-10s %-10s %-10.0f",id, name, basePrice);
			}
}