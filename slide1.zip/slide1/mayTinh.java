package slide1;

public class mayTinh {
	public int tinhTong(int a, int b) {
		return a+b;
	}
	public double tinhTong(double a, int b) {
		return (int) (a+b);
	}
}
