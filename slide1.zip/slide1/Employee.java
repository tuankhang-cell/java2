package slide1;

public class Employee {

    private String id;
    private String name;
    private double basicSalary;

    public Employee(){}

    public Employee(String id, String name, double basicSalary){
        this.id = id;
        this.name = name;
        this.basicSalary = basicSalary;
    }

    public String getID(){
        return this.id;
    }

    public boolean setID(String id){
        if(id != null && !id.isEmpty()){
            this.id = id;
            return true;
        }else{
            return false;
        }
    }

    public String getName(){
        return this.name;
    }

    public void setName(String name){
        this.name = name;
    }

    public double getBasicSalary(){
        return this.basicSalary;
    }

    public boolean setBasicSalary(double basicSalary){
        if(basicSalary >= 0){
            this.basicSalary = basicSalary;
            return true;
        }else{
            return false;
        }
    }

    public double income(){
        return this.basicSalary;
    }

    @Override
    public String toString(){
        return String.format("%-10s %-15s %-10.0f", id, name, basicSalary);
    }
}