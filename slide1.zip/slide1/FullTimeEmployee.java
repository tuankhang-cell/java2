package slide1;

public class FullTimeEmployee extends Employee {

    private double bonus;
    private double penalty;

    public boolean setBonus(double bonus){
        if(bonus >= 0){
            this.bonus = bonus;
            return true;
        }else{
            return false;
        }
    }

    public boolean setPenalty(double penalty){
        if(penalty >= 0){
            this.penalty = penalty;
            return true;
        }else{
            return false;
        }
    }

    public double getBonus(){
        return bonus;
    }

    public double getPenalty(){
        return penalty;
    }

    @Override
    public double income(){
        return getBasicSalary() + bonus - penalty;
    }

    @Override
    public String toString(){
        return String.format("%-10s %-10s %-10.0f %-10.0f %-10.0f",
                getID(), getName(), getBasicSalary(), bonus, penalty);
    }
}