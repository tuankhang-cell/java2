package slide1;

import java.util.ArrayList;

public class SLIDE1 {
	public static void main(String[] args) {
		ArrayList<PRODUCT> dsPRODUCT =new ArrayList<PRODUCT>();
		ImportedProduct iP=new ImportedProduct();
		iP.setID("Ao01");
		iP.setName("Ao thun");
		iP.setBasePrice(10);
		iP.setImportTaxRate(0.1);
		iP.setShippingFee(2);
		dsPRODUCT.add(iP);
		
		ImportedProduct iP2=new ImportedProduct();
		iP2.setID("Ao02");
		iP2.setName("Ao so mi");
		iP2.setBasePrice(12);
		iP2.setImportTaxRate(0.15);
		iP2.setShippingFee(1);
		dsPRODUCT.add(iP2);
		
		for(PRODUCT p : dsPRODUCT){
            System.out.println(p.toString() + " Final Price: " + p.finalPrice());
        }

        PRODUCT max = dsPRODUCT.get(0);

        for(PRODUCT p : dsPRODUCT){
            if(p.finalPrice() > max.finalPrice()){
                max = p;
            }
        }

        System.out.println("\nSan pham gia cao nhat:");
        System.out.println(max.toString() + " Final Price: " + max.finalPrice());
		}
}
