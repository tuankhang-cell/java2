package slide1;
import java.util.ArrayList;
public class Main {
	public static void main(String[] args) {
		ArrayList<Vehicle> ds = new ArrayList<>();
		
		ImportedVehicle i1 = new ImportedVehicle();
		i1.setID("Xe01");
		i1.setName("Vision");
		i1.setBasePrice(10);
		i1.setImportTaxRate(0.1);
		i1.setShippingFee(3);
		ds.add(i1);
		
		ImportedVehicle i2 = new ImportedVehicle();
		i2.setID("Xe02");
		i2.setName("SH");
		i2.setBasePrice(9);
		i2.setImportTaxRate(0.2);
		i2.setShippingFee(2);
		ds.add(i2);
		
		ElectricVehicle e1 = new ElectricVehicle();
		e1.setID("Xe03");
		e1.setName("Vinfast");
		e1.setBasePrice(10);
		e1.setBatteryCapacity(5000);
		e1.setSubsidy(200);
		ds.add(e1);
		
		ElectricVehicle e2 = new ElectricVehicle();
		e2.setID("Xe04");
		e2.setName("Vinfast");
		e2.setBasePrice(10);
		e2.setBatteryCapacity(6000);
		e2.setSubsidy(300);
		ds.add(e2);
		System.out.println("Danh sach xe:");
        for(Vehicle e : ds){
            System.out.println(e.toString() + " Income: " + ((ImportedVehicle) e).income());
        }

        Vehicle max = ds.get(0);

        for(Vehicle e : ds){
            if(((ImportedVehicle) e).income() > ((ImportedVehicle) max).income()){
                max = e;
            }
	}
}
}
