package slide1;

public class ElectricVehicle extends Vehicle {
	private double batteryCapacity;
	private double subsidy;
	
	public boolean batteryCapacity(double Capacity) {
		if (Capacity>=0) {
		this.batteryCapacity = Capacity;
		return true;
		}else {
			return false;
		}
	}
	public boolean subsidy(double sidy) {
		if(sidy>=0) {
			this.subsidy=sidy;
			return true;
		}else {
			return false;
		}
	}
	public double getBatteryCapacity() {
		return batteryCapacity;
	}
	public void setBatteryCapacity(double batteryCapacity) {
		this.batteryCapacity = batteryCapacity;
	}
	public double getSubsidy() {
		return subsidy;
	}
	public void setSubsidy(double subsidy) {
		this.subsidy = subsidy;
	}
	
	public double income() {
		return getBasePrice() + batteryCapacity * 5 - subsidy;
	}
	public String toString(){
		return String.format("%-10s %-10s %-10.0f %-10.0f",
                getId(), getName(), getBatteryCapacity(), subsidy);
}
	
}
