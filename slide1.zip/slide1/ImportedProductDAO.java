package slide1;

import java.util.Scanner;

public class ImportedProductDAO extends ImportedProduct {

    Scanner sc = new Scanner(System.in);

    public boolean NewImportedProduct() {

        String id;

        do {
            System.out.print("Nhap id: ");
            id = sc.nextLine();
        } while (!this.setID(id));

        System.out.print("Nhap ten: ");
        this.setName(sc.nextLine());

        double basePrice;
        do {
            System.out.print("Nhap gia: ");
            basePrice = sc.nextDouble();
            sc.nextLine();
        } while (!this.setBasePrice(basePrice));

        double shippingFee;
        do {
            System.out.print("Nhap phi van chuyen: ");
            shippingFee = sc.nextDouble();
            sc.nextLine();
        } while (!this.setShippingFee(shippingFee));

        return true;
    }
}