package slide1;
import java.util.ArrayList;
public class mainbai2 {
	   public static void main(String[] args) {

        ArrayList<Employee> ds = new ArrayList<>();

        FullTimeEmployee f1 = new FullTimeEmployee();
        f1.setID("E01");
        f1.setName("An");
        f1.setBasicSalary(1000);
        f1.setBonus(200);
        f1.setPenalty(50);
        ds.add(f1);

        FullTimeEmployee f2 = new FullTimeEmployee();
        f2.setID("E02");
        f2.setName("Binh");
        f2.setBasicSalary(1200);
        f2.setBonus(150);
        f2.setPenalty(30);
        ds.add(f2);

        PartTimeEmployee p1 = new PartTimeEmployee();
        p1.setID("E03");
        p1.setName("Chi");
        p1.setWorkingHours(80);
        p1.setHourlyRate(10);
        ds.add(p1);

        PartTimeEmployee p2 = new PartTimeEmployee();
        p2.setID("E04");
        p2.setName("Dung");
        p2.setWorkingHours(60);
        p2.setHourlyRate(12);
        ds.add(p2);

        PartTimeEmployee p3 = new PartTimeEmployee();
        p3.setID("E05");
        p3.setName("Hoa");
        p3.setWorkingHours(100);
        p3.setHourlyRate(9);
        ds.add(p3);

        System.out.println("Danh sach nhan vien:");
        for(Employee e : ds){
            System.out.println(e.toString() + " Income: " + e.income());
        }

        Employee max = ds.get(0);

        for(Employee e : ds){
            if(e.income() > max.income()){
                max = e;
            }
        }

        System.out.println("\nNhan vien co thu nhap cao nhat:");
        System.out.println(max.toString() + " Income: " + max.income());
	    }
	}

