package slide1;

public class PartTimeEmployee extends Employee {

    private double workingHours;
    private double hourlyRate;

    public boolean setWorkingHours(double workingHours){
        if(workingHours >= 0){
            this.workingHours = workingHours;
            return true;
        }else{
            return false;
        }
    }

    public boolean setHourlyRate(double hourlyRate){
        if(hourlyRate >= 0){
            this.hourlyRate = hourlyRate;
            return true;
        }else{
            return false;
        }
    }

    public double getWorkingHours(){
        return workingHours;
    }

    public double getHourlyRate(){
        return hourlyRate;
    }

    @Override
    public double income(){
        return workingHours * hourlyRate;
    }

    @Override
    public String toString(){
        return String.format("%-10s %-10s %-10.0f %-10.0f",
                getID(), getName(), workingHours, hourlyRate);
    }
}