package slide1;

public class ImportedVehicle extends Vehicle {
	private double importTaxRate;
	private double shippingFee;
	
	public boolean importTaxRate(double taxRate) {
		if(taxRate >=0 && taxRate <=1) {
			this.importTaxRate = taxRate;
			return true;
		}else {
			return false;
		}
	}
	public boolean shippingFee(double Fee) {
		if(Fee >=0) {
			this.shippingFee=Fee;
			return true;
		}else {
			return false;
		}
	}
	public double getImportTaxRate() {
		return importTaxRate;
	}
	public void setImportTaxRate(double importTaxRate) {
		this.importTaxRate = importTaxRate;
	}
	public double getShippingFee() {
		return shippingFee;
	}
	public void setShippingFee(double shippingFee) {
		this.shippingFee = shippingFee;
	}
	public double income() {
		return getBasePrice() + getBasePrice() * importTaxRate + shippingFee;
	}
	public String toString(){
		return String.format("%-10s %-10s %-10.0f %-10.0f",
                getId(), getName(), getImportTaxRate(), shippingFee);
}
}