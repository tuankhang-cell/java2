package slide1;

public class mainxe {
	    public static void main(String[] args) {
	        System.out.println("21	PS48351	Nguyễn Tuấn Khang");
//	        xe xe =new xe();
//	        xe.setHangXe("Vinfast");
//	        xe.setNamSanXuat(2020);
//	        xe.Xuat();
	        xe xe = new xe("Toyota", 2025);
	        xe.Xuat();
	        mayTinh maytinh = new mayTinh();
	        double tong1 = maytinh.tinhTong(23, 36);
	        System.out.println(tong1);
	    }
	}