package slide1;

public class ImportedProduct extends PRODUCT {

    private double importTaxRate;
    private double shippingFee;

    private boolean importTaxRate(double taxRate) {
        if (taxRate >= 0 && taxRate <= 1) {
            this.importTaxRate = taxRate;
            return true;
        } else {
            return false;
        }
    }

    public boolean shippingFee(double fee) {
        if (fee >= 0) {
            this.shippingFee = fee;
            return true;
        } else {
            return false;
        }
    }

	public double getImportTaxRate() {
		return importTaxRate;
	}

	public void setImportTaxRate(double importTaxRate) {
		this.importTaxRate = importTaxRate;
	}

	public double getShippingFee() {
		return shippingFee;
	}

	public void setShippingFee(double shippingFee) {
		this.shippingFee = shippingFee;
	}
    
}